import type { FunctionArgument } from './argument/function-argument.ts';

export type FunctionArguments = readonly FunctionArgument[];
