export type FunctionArgument = readonly [name: string, value: string];
