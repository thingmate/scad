import type { FunctionArgument } from './function-argument.ts';
import type { FunctionArguments } from '../function-arguments.ts';

/**
 * Generates an array of function arguments based on the provided value and transformation function.
 * If the value is undefined, returns an empty array.
 *
 * @template GValue - The type of the input value.
 * @param {GValue | undefined} value - The input value which can be either of type GValue or undefined.
 * @param {(value: GValue) => FunctionArgument} getArgument - A transformation function that takes a GValue input and returns a FunctionArgument.
 * @return {readonly FunctionArgument[]} An array of function arguments, which is empty if the value is undefined.
 */
export function optionalFunctionArgument<GValue>(
  value: GValue | undefined,
  getArgument: (value: GValue) => FunctionArgument,
): FunctionArguments {
  return value === undefined ? [] : [getArgument(value)];
}
