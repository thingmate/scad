import type { FunctionArgument } from '../function-argument.ts';
import { dedent } from '../../../../../../misc/dedent/dedent.ts';

/**
 * Serializes a function argument into a formatted string (open-scad format).
 *
 * @param {FunctionArgument} argument - The function's argument.
 * @return {string} A string representation of the function argument.
 */
export function serializeFunctionArgument([name, value]: FunctionArgument): string {
  return dedent`
    ${name} = ${value}
  `;
}
