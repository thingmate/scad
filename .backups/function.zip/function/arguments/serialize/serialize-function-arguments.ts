import type { FunctionArguments } from '../function-arguments.ts';
import { serializeFunctionArgument } from '../argument/serialize/serialize-function-argument.ts';

/**
 * Serializes an array of function arguments into a string representation (open-scad format).
 *
 * @param {FunctionArguments} args - The array of function arguments to be serialized.
 * @return {string} A string representation of the serialized function arguments.
 */
export function serializeFunctionArguments(args: FunctionArguments): string {
  return args.map(serializeFunctionArgument).join(',\n');
}
