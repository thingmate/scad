import { trait } from '../src/trait.ts';
import type { Rgba } from '../../types/rgba/rgba.ts';
import type { Typed } from '../src/typed.ts';

export interface ApplyColor {
  <GSelf extends Typed>(self: GSelf, color: Rgba): GSelf;
}

export const applyColor = trait<ApplyColor>();
