import { trait } from '../src/trait.ts';
import type { Typed } from '../src/typed.ts';

export interface Difference {
  <GSelf extends Typed>(self: GSelf, ...shapes: GSelf[]): GSelf;
}

export const difference = trait<Difference>();
