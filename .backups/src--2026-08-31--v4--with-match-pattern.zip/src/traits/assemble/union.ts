import { trait } from '../src/trait.ts';
import type { Typed } from '../src/typed.ts';

export interface Union {
  <GSelf extends Typed>(self: GSelf, ...shapes: GSelf[]): GSelf;
}

export const union = trait<Union>();
