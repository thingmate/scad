import { trait } from '../src/trait.ts';
import type { Typed } from '../src/typed.ts';

export interface Intersection {
  <GSelf extends Typed>(self: GSelf, ...shapes: GSelf[]): GSelf;
}

export const intersection = trait<Intersection>();
