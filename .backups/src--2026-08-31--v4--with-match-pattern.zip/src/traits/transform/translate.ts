import { trait } from '../src/trait.ts';
import type { Typed } from '../src/typed.ts';

export interface Translate {
  <GSelf extends Typed>(self: GSelf, x: number, y?: number, z?: number): GSelf;
}

export const translate = trait<Translate>();
