import type { Typed } from './typed.ts';

export type TraitDefinitionConstraint = (self: Typed, ...args: any) => any;

export type HandleTypedSelf<GSelf> = GSelf extends Typed ? GSelf & any : never;

export type HandleTypedArgs<GArgs extends readonly unknown[]> = {
  [GKey in keyof GArgs]: GArgs[GKey] extends Typed ? GArgs[GKey] & any : GArgs[GKey];
};

export type HandleTypedReturn<GReturn> = GReturn extends Typed ? GReturn & any : GReturn;

export type TraitImplementationConstraint<GTraitDefinition extends TraitDefinitionConstraint> =
  GTraitDefinition extends (self: infer GSelf, ...args: infer GArgs) => infer GReturn
    ? (self: HandleTypedSelf<GSelf>, ...args: HandleTypedArgs<GArgs>) => HandleTypedReturn<GReturn>
    : never;

export type InferImplementationType<GImplementation extends TraitDefinitionConstraint> =
  GImplementation extends (self: infer GSelf, ...args: any) => any
    ? GSelf extends Typed<infer GType>
      ? GType
      : never
    : never;

export type InferCurryArgs<GTraitDefinition extends TraitDefinitionConstraint> =
  GTraitDefinition extends (self: any, ...args: infer GArgs) => any ? GArgs : never;

export type InferCurryReturn<GTraitDefinition extends TraitDefinitionConstraint> =
  GTraitDefinition extends (self: infer GSelf, ...args: any) => infer GReturn
    ? (self: GSelf) => GReturn
    : never;

export type Trait<GTraitDefinition extends TraitDefinitionConstraint> = GTraitDefinition & {
  implement<GImplementation extends TraitImplementationConstraint<GTraitDefinition>>(
    $type: InferImplementationType<GImplementation>,
    implementation: GImplementation,
  ): void;

  curry(...args: InferCurryArgs<GTraitDefinition>): InferCurryReturn<GTraitDefinition>;
};

export function trait<
  GTraitDefinition extends TraitDefinitionConstraint,
>(): Trait<GTraitDefinition> {
  const implementations: Map<symbol, TraitImplementationConstraint<GTraitDefinition>> = new Map();

  return Object.assign(
    (self: Typed, ...args: any[]): any => {
      return implementations.get(self.$type)!(self, ...args);
    },
    {
      implement<GImplementation extends TraitImplementationConstraint<GTraitDefinition>>(
        $type: InferImplementationType<GImplementation>,
        implementation: GImplementation,
      ): void {
        if (implementations.has($type)) {
          throw new Error(`Trait already implemented for type ${String($type)}.`);
        }
        implementations.set($type, implementation);
      },
    },
  ) as Trait<GTraitDefinition>;
}
