import { translate } from '../../../../traits/transform/translate.ts';
import { BOM_PART } from '../../bom-part.ts';
import { bomPart_translate } from './bom-part.translate.ts';

export function implement_bomPart_translate(): void {
  translate.implement(BOM_PART, bomPart_translate);
}
