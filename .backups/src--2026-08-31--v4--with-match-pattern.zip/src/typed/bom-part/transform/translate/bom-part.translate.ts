import { type BomPart } from '../../bom-part.ts';

export function bomPart_translate(self: BomPart, x?: number, y?: number, z?: number): BomPart {
  return self;
}
