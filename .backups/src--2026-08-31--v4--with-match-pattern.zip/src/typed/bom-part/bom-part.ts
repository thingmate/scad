import type { Typed } from '../../traits/src/typed.ts';

export const BOM_PART = Symbol('BOM_PART');

export interface BomPart extends Typed<typeof BOM_PART> {
  readonly name: string;
  readonly shopUrl: string | undefined;
  readonly price: number | undefined;
}

export interface BomPartOptions {
  readonly name: string;
  readonly shopUrl?: string;
  readonly price?: number;
}

export function bomPart({ name, shopUrl, price }: BomPartOptions): BomPart {
  return {
    $type: BOM_PART,
    name,
    shopUrl,
    price,
  };
}

export function isBomPart(input: Typed): input is BomPart {
  return input.$type === BOM_PART;
}
