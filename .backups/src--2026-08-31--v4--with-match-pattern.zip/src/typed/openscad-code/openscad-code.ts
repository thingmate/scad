import type { Typed } from '../../traits/src/typed.ts';

export const OPENSCAD_CODE = Symbol('OPENSCAD_CODE');

export interface OpenscadCode extends Typed<typeof OPENSCAD_CODE> {
  readonly code: string;
}

export function openscadCode(code: string): OpenscadCode {
  return {
    $type: OPENSCAD_CODE,
    code,
  };
}

export function isOpenscadCode(input: Typed): input is OpenscadCode {
  return input.$type === OPENSCAD_CODE;
}
