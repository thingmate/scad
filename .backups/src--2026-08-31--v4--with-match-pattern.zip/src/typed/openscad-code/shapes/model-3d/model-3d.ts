import { openscadCode, type OpenscadCode } from '../../openscad-code.ts';

/**
 * @inheritDoc https://en.wikibooks.org/wiki/OpenSCAD_User_Manual/Importing_Geometry#import
 */
export function model3d(path: string): OpenscadCode {
  return openscadCode(`import(${path});`);
}
