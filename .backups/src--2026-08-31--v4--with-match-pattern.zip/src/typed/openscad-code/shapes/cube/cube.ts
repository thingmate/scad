import { openscadCode, type OpenscadCode } from '../../openscad-code.ts';
import { vector3ToOpenscad } from '../../../../types/vector-3/to/openscad/vector-3-to-openscad.ts';

/**
 * @inheritDoc https://en.wikibooks.org/wiki/OpenSCAD_User_Manual/Primitive_Solids#cube
 */
export function cube(x: number, y: number, z: number): OpenscadCode {
  return openscadCode(`cube(size = ${vector3ToOpenscad([x, y, z])}, center = true);`);
}
