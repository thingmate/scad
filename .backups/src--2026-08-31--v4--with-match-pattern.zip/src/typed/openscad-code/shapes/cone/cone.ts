import { openscadCode, type OpenscadCode } from '../../openscad-code.ts';
import { numberToOpenscad } from '../../../../types/number/to/openscad/number-to-openscad.ts';

/**
 * @inheritDoc https://en.wikibooks.org/wiki/OpenSCAD_User_Manual/Primitive_Solids#cylinder
 */
export function cone(
  height: number,
  radiusBottom: number,
  radiusTop: number,
  subDivisions: number = 16,
): OpenscadCode {
  return openscadCode(
    `cylinder(h = ${numberToOpenscad(height)}, r1 = ${numberToOpenscad(radiusBottom)}, r2 = ${numberToOpenscad(radiusTop)}, center = true, $fn = ${numberToOpenscad(subDivisions)});`,
  );
}
