import { openscadCode, type OpenscadCode } from '../../openscad-code.ts';
import { numberToOpenscad } from '../../../../types/number/to/openscad/number-to-openscad.ts';
import { vector3ToOpenscad } from '../../../../types/vector-3/to/openscad/vector-3-to-openscad.ts';
import type { Vector3 } from '../../../../types/vector-3/vector-3.ts';

/**
 * @inheritDoc https://en.wikibooks.org/wiki/OpenSCAD_User_Manual/Primitive_Solids#polyhedron
 */
export function polyhedron(points: readonly Vector3[], faces: readonly number[]): OpenscadCode {
  return openscadCode(
    `polyhedron(points = ${points.map(vector3ToOpenscad)}, points = ${faces.map(numberToOpenscad)});`,
  );
}
