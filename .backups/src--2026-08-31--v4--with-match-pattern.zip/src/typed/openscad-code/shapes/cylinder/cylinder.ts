import type { OpenscadCode } from '../../openscad-code.ts';
import { cone } from '../cone/cone.ts';

export function cylinder(height: number, radius: number, subDivisions?: number): OpenscadCode {
  return cone(height, radius, radius, subDivisions);
}
