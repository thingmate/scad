import { openscadCode_intersection } from './openscad-code.intersection.ts';
import { intersection } from '../../../../traits/assemble/intersection.ts';
import { OPENSCAD_CODE } from '../../openscad-code.ts';

export function implement_openscadCode_intersection(): void {
  intersection.implement(OPENSCAD_CODE, openscadCode_intersection);
}
