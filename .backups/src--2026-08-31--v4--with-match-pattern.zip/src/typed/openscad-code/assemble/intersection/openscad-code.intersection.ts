import { dedent } from '../../../../misc/string/dedent/dedent.ts';
import { openscadCode, type OpenscadCode } from '../../openscad-code.ts';

export function openscadCode_intersection(
  self: OpenscadCode,
  ...shapes: OpenscadCode[]
): OpenscadCode {
  return openscadCode(
    dedent`
      intersection() {
        ${self.code}
        ${shapes.map((shape: OpenscadCode): string => shape.code).join('\n')}
      }
    `,
  );
}
