import { dedent } from '../../../../misc/string/dedent/dedent.ts';
import { openscadCode, type OpenscadCode } from '../../openscad-code.ts';

export function openscadCode_union(
  self: OpenscadCode,
  ...shapes: OpenscadCode[]
): OpenscadCode {
  return openscadCode(
    dedent`
      union() {
        ${self.code}
        ${shapes.map((shape: OpenscadCode): string => shape.code).join('\n')}
      }
    `,
  );
}
