import { openscadCode_union } from './openscad-code.union.ts';
import { union } from '../../../../traits/assemble/union.ts';
import { OPENSCAD_CODE } from '../../openscad-code.ts';

export function implement_openscadCode_union(): void {
  union.implement(OPENSCAD_CODE, openscadCode_union);
}
