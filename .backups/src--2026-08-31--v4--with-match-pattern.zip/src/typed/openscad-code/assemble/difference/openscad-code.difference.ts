import { dedent } from '../../../../misc/string/dedent/dedent.ts';
import { openscadCode, type OpenscadCode } from '../../openscad-code.ts';

export function openscadCode_difference(
  self: OpenscadCode,
  ...shapes: OpenscadCode[]
): OpenscadCode {
  return openscadCode(
    dedent`
      difference() {
        ${self.code}
        ${shapes.map((shape: OpenscadCode): string => shape.code).join('\n')}
      }
    `,
  );
}
