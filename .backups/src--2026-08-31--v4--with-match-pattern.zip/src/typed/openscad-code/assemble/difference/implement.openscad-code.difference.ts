import { openscadCode_difference } from './openscad-code.difference.ts';
import { difference } from '../../../../traits/assemble/difference.ts';
import { OPENSCAD_CODE } from '../../openscad-code.ts';

export function implement_openscadCode_difference(): void {
  difference.implement(OPENSCAD_CODE, openscadCode_difference);
}
