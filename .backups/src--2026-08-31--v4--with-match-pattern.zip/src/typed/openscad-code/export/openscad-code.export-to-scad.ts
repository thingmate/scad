import { writeTextFileSafe } from '../../../misc/file/write-text-file-safe.ts';
import type { OpenscadCode } from '../openscad-code.ts';

export function openscadCode_exportToScad(self: OpenscadCode, path: string): Promise<void> {
  return writeTextFileSafe(path, self.code + '\n');
}
