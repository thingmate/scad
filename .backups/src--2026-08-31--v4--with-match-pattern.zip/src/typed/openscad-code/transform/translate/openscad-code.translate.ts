import { dedent } from '../../../../misc/string/dedent/dedent.ts';
import { vector3ToOpenscad } from '../../../../types/vector-3/to/openscad/vector-3-to-openscad.ts';
import { openscadCode, type OpenscadCode } from '../../openscad-code.ts';

export function openscadCode_translate(
  self: OpenscadCode,
  x: number,
  y: number = 0,
  z: number = 0,
): OpenscadCode {
  return openscadCode(
    dedent`
      translate(${vector3ToOpenscad([x, y, z])}) {
        ${self.code}
      }
    `,
  );
}
