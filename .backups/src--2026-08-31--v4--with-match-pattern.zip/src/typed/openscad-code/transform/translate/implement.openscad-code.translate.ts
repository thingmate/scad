import { translate } from '../../../../traits/transform/translate.ts';
import { OPENSCAD_CODE } from '../../openscad-code.ts';
import { openscadCode_translate } from './openscad-code.translate.ts';

export function implement_openscadCode_translate(): void {
  translate.implement(OPENSCAD_CODE, openscadCode_translate);
}
