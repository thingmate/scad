import { applyColor } from '../../../../traits/misc/apply-color.ts';
import { openscadCode_applyColor } from './openscad-code.apply-color.ts';
import { OPENSCAD_CODE } from '../../openscad-code.ts';

export function implement_openscadCode_applyColor(): void {
  applyColor.implement(OPENSCAD_CODE, openscadCode_applyColor);
}
