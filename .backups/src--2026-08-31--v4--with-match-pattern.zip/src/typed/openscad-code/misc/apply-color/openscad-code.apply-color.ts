import { dedent } from '../../../../misc/string/dedent/dedent.ts';
import { openscadCode, type OpenscadCode } from '../../openscad-code.ts';
import type { Rgba } from '../../../../types/rgba/rgba.ts';
import { rgbaToOpenscad } from '../../../../types/rgba/to/openscad/rgba-to-openscad.ts';

export function openscadCode_applyColor(self: OpenscadCode, rgba: Rgba): OpenscadCode {
  return openscadCode(
    dedent`
      color(${rgbaToOpenscad(rgba)}) {
        ${self.code}
      }
    `,
  );
}
