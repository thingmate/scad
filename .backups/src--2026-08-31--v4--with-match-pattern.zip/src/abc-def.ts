import {
  aggregatePatternMatchers,
  patternMatcher,
  MATCH_PATTERN,
} from './traits/$match/matcher.ts';
import { bomPart, isBomPart } from './typed/bom-part/bom-part.ts';
import { bomPart_translate } from './typed/bom-part/transform/translate/bom-part.translate.ts';
import { implement_bomPart_translate } from './typed/bom-part/transform/translate/implement.bom-part.translate.ts';
import { implement_openscadCode_difference } from './typed/openscad-code/assemble/difference/implement.openscad-code.difference.ts';
import { implement_openscadCode_intersection } from './typed/openscad-code/assemble/intersection/implement.openscad-code.intersection.ts';
import { implement_openscadCode_union } from './typed/openscad-code/assemble/union/implement.openscad-code.union.ts';
import { implement_openscadCode_applyColor } from './typed/openscad-code/misc/apply-color/implement.openscad-code.apply-color.ts';
import { isOpenscadCode } from './typed/openscad-code/openscad-code.ts';
import { cube } from './typed/openscad-code/shapes/cube/cube.ts';
import { implement_openscadCode_translate } from './typed/openscad-code/transform/translate/implement.openscad-code.translate.ts';
import { openscadCode_translate } from './typed/openscad-code/transform/translate/openscad-code.translate.ts';
import { COLOR_WOOD } from './types/rgba/built-in/wood.ts';

/*---------*/

/*---------*/

export const translate = aggregatePatternMatchers([
  patternMatcher(isOpenscadCode, openscadCode_translate),
  patternMatcher(isBomPart, bomPart_translate),
]);

translate(cube(1, 2, 3), 10);
translate(
  bomPart({
    name: 'wood',
    shopUrl: 'https://www.amazon.fr/gp/product/B000000000',
    price: 100,
  }),
  10,
);

/*---------*/

export function wood() {
  return [
    bomPart({
      name: 'wood',
      shopUrl: 'https://www.amazon.fr/gp/product/B000000000',
      price: 100,
    }),
    translate(applyColor(cube(1, 2, 3), COLOR_WOOD), 0, 1, 2),
  ];
}

export function window(width: number, height: number) {
  return [
    bomPart({
      name: `window_${width}x${height}`,
      shopUrl: 'https://www.amazon.fr/gp/product/B000000000',
      price: 100,
    }),
    applyColor(cube(1, 2, 3), COLOR_WOOD),
  ];
}

/*---------*/

export function mainTrait() {
  implement_openscadCode_translate();
  implement_bomPart_translate();

  implement_openscadCode_union();
  implement_openscadCode_difference();
  implement_openscadCode_intersection();
  implement_openscadCode_applyColor();

  // const r = translate(vec3(1, 2, 3), 10);
  // console.log([vec3(1, 2, 3), vec3(11, 12, 13)].map(translate.curry(10)));
  // console.log(r);

  const c = wood();
  // console.log(c.map((_) => translate(_, 4, 5, 6)));

  const d = c.map(translate.curry(4, 5, 6));

  console.log();
}
