export type Rgba = [
  r: number, // [0, 1]
  g: number, // [0, 1]
  b: number, // [0, 1]
  a?: number, // [0, 1]
];
