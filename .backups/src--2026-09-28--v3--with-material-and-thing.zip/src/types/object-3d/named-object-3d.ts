import { dedent } from '../../misc/string/dedent/dedent.ts';
import { Object3d } from './object-3d.ts';

export abstract class NamedObject3d extends Object3d {
  readonly name: string;

  protected constructor(name: string) {
    super();
    this.name = name;
  }

  override toOpenscad(content: string): string {
    return dedent`
      // object: ${this.name}
      ${super.toOpenscad(content)}
    `;
  }
}
