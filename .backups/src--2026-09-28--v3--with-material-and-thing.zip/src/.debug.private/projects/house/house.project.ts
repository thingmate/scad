import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { AssembledMaterial } from '../../../materials/assembled/assembled-material.ts';
import { AtomicMaterial } from '../../../materials/atomic/atomic-material.ts';
import { Material } from '../../../materials/material.ts';
import { EPSILON } from '../../../math/epsilon.ts';
import { deg } from '../../../math/units/angle/deg.ts';
import { cm } from '../../../math/units/length/1d/cm.ts';
import { meter } from '../../../math/units/length/1d/meter.ts';
import { difference, Difference } from '../../../shapes/3d/assemble/difference/difference.ts';
import { cube, Cube } from '../../../shapes/3d/base/cube/cube.ts';
import { AssembledThing } from '../../../things/assembled/assembled-thing.ts';
import { AtomicThing } from '../../../things/atomic/atomic-thing.ts';
import { exportToBOM } from '../../../things/export/export-to-bom.ts';
import { exportToOpenscad } from '../../../things/export/export-to-openscad.ts';
import { cssRgb } from '../../../types/rgba/create/css-rgb.ts';
import { hex } from '../../../types/rgba/create/hex.ts';
import { rgba } from '../../../types/rgba/create/rgba.ts';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '../../../..');
const DIST = join(ROOT, 'dist');

export function material_wooden_beam_80x60(length: number): AtomicMaterial {
  return new AtomicMaterial('wooden_beam_80x60', hex('#a17752'), {
    shopUrl: 'https://www.etsy.com/listing/1240222222/wooden-beam-80x60-with-wood-frame',
    price: length * 10,
  });
}

export const MATERIAL_GLASS = new AtomicMaterial('glass', rgba('rgb(171 255 255 / 0.32)'));
export const MATERIAL_PVC = new AtomicMaterial('pvc', rgba('rgb(255 255 255)'));

export function material_window(width: number, height: number): AssembledMaterial {
  return new AssembledMaterial(`window_${width}x${height}`, {
    shopUrl: 'https://www.etsy.com/listing/1240222222/wooden-beam-80x60-with-wood-frame',
  });
}

export function thing_window(width: number, height: number, thickness: number): AssembledThing {
  const pvcThickness: number = cm(10);

  const glassWidth: number = width - pvcThickness * 2;
  const glassHeight: number = height - pvcThickness * 2;
  const glassThickness: number = thickness - cm(2);

  return new AssembledThing(
    `window_${width}x${height}x${thickness}`,
    [
      new AtomicThing('glass', MATERIAL_GLASS, cube(glassWidth, glassThickness, glassHeight)),
      new AtomicThing(
        'pvc',
        MATERIAL_PVC,
        difference(
          cube(width, thickness, height),
          cube(glassWidth, thickness + EPSILON, glassHeight),
        ),
      ),
    ],
    material_window(width, height),
  );
}

// export function material_wooden_beam_80x60(length: number): Material {
//   return new Material({
//     name: 'wooden_beam_80x60',
//     color: hex('#a17752'),
//     shopUrl: 'https://www.etsy.com/listing/1240222222/wooden-beam-80x60-with-wood-frame',
//     price: length * 10,
//   });
// }

export async function houseProject() {
  // const poutre_01 = new AtomicThing('a', material_wooden_beam_80x60(5), new Cube(1, 2, 30));

  // const scene = new AssembledThing('window', [poutre_01], material_glass(5, 5, 5)).rotateX(deg(45));
  const scene = thing_window(meter(1.2), meter(0.8), cm(8));

  await exportToOpenscad(join(DIST, 'main.scad'), scene);
  await exportToBOM(join(DIST, 'bom.csv'), scene);

  console.log('done');
}
