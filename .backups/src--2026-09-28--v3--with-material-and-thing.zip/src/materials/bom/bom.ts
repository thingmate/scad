import type { Material } from '../material.ts';

export type BOM = Map<Material, number>;
