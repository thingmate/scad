import type { BOM } from '../../bom.ts';

/**
 * @inheritDoc https://en.wikipedia.org/wiki/Comma-separated_values
 */
export function bomToCSV(input: BOM): string {
  let output: string = 'name,shop url, unit price, quantity, total price\r\n';

  for (const [material, quantity] of input.entries()) {
    output += `${formatCell(material.name)},${formatOptionalCell(material.shopUrl)},${material.price === undefined ? '' : material.price},${quantity},${material.price === undefined ? '' : material.price * quantity}\r\n`;
  }

  return output;
}

/*--*/

function formatOptionalNumber(input: number | undefined): string {
  return input === undefined ? '' : formatCell(input.toString(10));
}

function formatOptionalCell(input: string | undefined): string {
  return input === undefined ? '' : formatCell(input);
}

function formatCell(input: string): string {
  if (input.includes(',') || input.includes('"') || input.includes('\r') || input.includes('\n')) {
    return `"${input.replaceAll('"', '""')}"`;
  } else {
    return input;
  }
}
