import { dedent } from '../../misc/string/dedent/dedent.ts';
import type { Rgba } from '../../types/rgba/rgba.ts';
import { rgbaToOpenscad } from '../../types/rgba/to/openscad/rgba-to-openscad.ts';
import { Material, type MaterialInit } from '../material.ts';

export class AtomicMaterial extends Material {
  readonly color: Rgba;

  constructor(name: string, color: Rgba, options?: MaterialInit) {
    super(name, options);
    this.color = color;
  }

  override toOpenscad(content: string): string {
    return super.toOpenscad(
      dedent`
        color(c = ${rgbaToOpenscad(this.color)}) {
          ${content}
        }
      `,
    );
  }
}
