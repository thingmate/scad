import { Material } from '../material.ts';

export class AssembledMaterial extends Material {}
