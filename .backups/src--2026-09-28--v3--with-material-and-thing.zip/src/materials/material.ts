import { dedent } from '../misc/string/dedent/dedent.ts';

export interface MaterialInit {
  readonly shopUrl?: string;
  readonly price?: number;
}

export abstract class Material {
  readonly name: string;
  readonly shopUrl: string | undefined;
  readonly price: number | undefined;

  constructor(name: string, { shopUrl, price }: MaterialInit = {}) {
    this.name = name;
    this.shopUrl = shopUrl;
    this.price = price;
  }

  toOpenscad(content: string): string {
    return dedent`
      // material: ${this.name}
      ${content}
    `;
  }
}
