import type { BOM } from '../materials/bom/bom.ts';
import { NamedObject3d } from '../types/object-3d/named-object-3d.ts';

export abstract class Thing extends NamedObject3d {
  protected constructor(name: string) {
    super(name);
  }

  abstract override toOpenscad(): string;

  abstract toBOM(input?: BOM): BOM;
}
