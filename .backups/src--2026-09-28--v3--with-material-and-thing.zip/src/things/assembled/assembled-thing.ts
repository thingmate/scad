import { AssembledMaterial } from '../../materials/assembled/assembled-material.ts';
import type { BOM } from '../../materials/bom/bom.ts';
import { NamedObject3d } from '../../types/object-3d/named-object-3d.ts';
import { Thing } from '../thing.ts';

export class AssembledThing extends Thing {
  readonly children: readonly Thing[];
  readonly material: AssembledMaterial | undefined;

  constructor(name: string, children: readonly Thing[], material?: AssembledMaterial) {
    super(name);
    this.children = children;
    this.material = material;
  }

  override toOpenscad(): string {
    let output: string = '';
    for (const child of this.children) {
      if (output !== '') {
        output += '\n';
      }
      output += child.toOpenscad();
    }
    output = NamedObject3d.prototype.toOpenscad.call(this, output);
    // super.toOpenscad
    return this.material === undefined ? output : this.material.toOpenscad(output);
  }

  override toBOM(input: BOM = new Map()): BOM {
    if (this.material === undefined) {
      for (const child of this.children) {
        child.toBOM(input);
      }
    } else {
      input.set(this.material, (input.get(this.material) ?? 0) + 1);
    }
    return input;
  }
}
