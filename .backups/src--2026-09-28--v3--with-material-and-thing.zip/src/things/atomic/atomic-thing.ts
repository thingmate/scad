import type { AtomicMaterial } from '../../materials/atomic/atomic-material.ts';
import type { BOM } from '../../materials/bom/bom.ts';
import type { Shape3d } from '../../shapes/3d/shape-3d.ts';
import { NamedObject3d } from '../../types/object-3d/named-object-3d.ts';
import { Thing } from '../thing.ts';

export class AtomicThing extends Thing {
  readonly material: AtomicMaterial;
  readonly shape: Shape3d;

  constructor(name: string, material: AtomicMaterial, shape: Shape3d) {
    super(name);
    this.material = material;
    this.shape = shape;
  }

  override toOpenscad(): string {
    // super.toOpenscad
    return NamedObject3d.prototype.toOpenscad.call(
      this,
      this.material.toOpenscad(this.shape.toOpenscad()),
    );
  }

  override toBOM(input: BOM = new Map()): BOM {
    input.set(this.material, (input.get(this.material) ?? 0) + 1);
    return input;
  }
}
