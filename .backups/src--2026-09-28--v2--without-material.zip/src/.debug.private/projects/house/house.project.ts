import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { EPSILON } from '../../../math/epsilon.ts';
import { cm } from '../../../math/units/length/1d/cm.ts';
import { meter } from '../../../math/units/length/1d/meter.ts';
import { mm } from '../../../math/units/length/1d/mm.ts';
import { difference } from '../../../shapes/3d/assemble/difference/difference.ts';
import { cube } from '../../../shapes/3d/base/cube/cube.ts';
import { assembledThing, AssembledThing } from '../../../things/assembled/assembled-thing.ts';
import { atomicThing, AtomicThing } from '../../../things/atomic/atomic-thing.ts';
import { exportToBOM } from '../../../things/export/export-to-bom.ts';
import { exportToOpenscad } from '../../../things/export/export-to-openscad.ts';
import { COLOR_GLASS } from '../../../types/rgba/built-in/glass.ts';
import { COLOR_WHITE_PVC } from '../../../types/rgba/built-in/whit-pvc.ts';
import { COLOR_WOOD } from '../../../types/rgba/built-in/wood.ts';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '../../../..');
const DIST = join(ROOT, 'dist');

export function thing_wooden_beam_80x60(length: number): AtomicThing {
  return atomicThing(`wooden_beam_80x60x${length}`, cube(length, mm(80), mm(60)), COLOR_WOOD, {
    shopUrl: 'https://www.etsy.com/listing/1240222222/wooden-beam-80x60-with-wood-frame',
    price: length * 10,
  });
}

export function thing_window(width: number, height: number, thickness: number): AssembledThing {
  const pvcThickness: number = cm(10);

  const glassWidth: number = width - pvcThickness * 2;
  const glassHeight: number = height - pvcThickness * 2;
  const glassThickness: number = thickness - cm(2);

  return assembledThing(
    `window_${width}x${height}x${thickness}`,
    [
      atomicThing('glass', cube(glassWidth, glassThickness, glassHeight), COLOR_GLASS),
      atomicThing(
        'pvc',
        difference(
          cube(width, thickness, height),
          cube(glassWidth, thickness + EPSILON, glassHeight),
        ),
        COLOR_WHITE_PVC,
      ),
    ],
    {
      shopUrl: 'https://www.etsy.com/listing/1240222222/wooden-beam-80x60-with-wood-frame',
    },
  );
}

export async function houseProject() {
  const scene = thing_window(meter(1.2), meter(0.8), cm(8));

  await exportToOpenscad(join(DIST, 'main.scad'), scene);
  await exportToBOM(join(DIST, 'bom.csv'), scene);

  console.log('done');
}
