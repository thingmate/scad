import { BOM } from '../../bom/bom.ts';
import { dedent } from '../../misc/string/dedent/dedent.ts';
import type { Shape3d } from '../../shapes/3d/shape-3d.ts';
import type { Rgba } from '../../types/rgba/rgba.ts';
import { rgbaToOpenscad } from '../../types/rgba/to/openscad/rgba-to-openscad.ts';
import { Thing, type ThingOptions } from '../thing.ts';

export class AtomicThing extends Thing {
  readonly shape: Shape3d;
  readonly color: Rgba;

  constructor(name: string, shape: Shape3d, color: Rgba, options?: ThingOptions) {
    super(name, options);
    this.shape = shape;
    this.color = color;
  }

  override toOpenscad(): string {
    return super.toOpenscad(
      dedent`
        color(c = ${rgbaToOpenscad(this.color)}) {
          ${this.shape.toOpenscad()}
        }
      `,
    );
  }

  override toBOM(bom: BOM = new BOM()): BOM {
    bom.add(this.name, this);
    return bom;
  }
}

/*--*/

export function atomicThing(
  name: string,
  shape: Shape3d,
  color: Rgba,
  options?: ThingOptions,
): AtomicThing {
  return new AtomicThing(name, shape, color, options);
}
