import { BOM } from '../../bom/bom.ts';
import { Thing, type ThingOptions } from '../thing.ts';

export class AssembledThing extends Thing {
  readonly children: readonly Thing[];

  constructor(name: string, children: readonly Thing[], options?: ThingOptions) {
    super(name, options);
    this.children = children;
  }

  override toOpenscad(): string {
    let output: string = '';
    for (const child of this.children) {
      if (output !== '') {
        output += '\n';
      }
      output += child.toOpenscad();
    }
    return super.toOpenscad(output);
  }

  override toBOM(bom: BOM = new BOM()): BOM {
    if (this.shopUrl !== undefined || this.price !== undefined) {
      bom.add(this.name, this);
    } else {
      for (const child of this.children) {
        child.toBOM(bom);
      }
    }
    return bom;
  }
}

/*--*/

export function assembledThing(
  name: string,
  children: readonly Thing[],
  options?: ThingOptions,
): AssembledThing {
  return new AssembledThing(name, children, options);
}
