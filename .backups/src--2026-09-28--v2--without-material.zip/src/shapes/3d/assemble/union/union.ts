import { dedent } from '../../../../misc/string/dedent/dedent.ts';
import { Shape3d } from '../../shape-3d.ts';

export class Union extends Shape3d {
  readonly shapes: readonly Shape3d[];

  constructor(shapes: readonly Shape3d[]) {
    super();
    this.shapes = shapes;
  }

  override toOpenscad(): string {
    let output: string = '';
    let count: number = 0;

    for (const shape of this.shapes) {
      count++;
      if (output !== '') {
        output += '\n';
      }
      output += shape.toOpenscad();
    }

    if (count === 1) {
      return dedent`
        union() {
          ${output}
        }
      `;
    } else {
      return output;
    }
  }
}
