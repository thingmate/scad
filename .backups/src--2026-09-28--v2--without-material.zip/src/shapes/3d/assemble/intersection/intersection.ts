import { dedent } from '../../../../misc/string/dedent/dedent.ts';
import { Shape3d } from '../../shape-3d.ts';

export class Intersection extends Shape3d {
  readonly shapeA: Shape3d;
  readonly shapeB: Shape3d;

  constructor(shapeA: Shape3d, shapeB: Shape3d) {
    super();
    this.shapeA = shapeA;
    this.shapeB = shapeB;
  }

  override toOpenscad(): string {
    return dedent`
      intersection() {
        ${this.shapeA.toOpenscad()}
        ${this.shapeB.toOpenscad()}
      }
    `;
  }
}
