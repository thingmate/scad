import { Object3d } from '../../../../types/object-3d/object-3d.ts';
import { vector3ToOpenscad } from '../../../../types/vector-3/to/openscad/vector-3-to-openscad.ts';
import { Shape3d } from '../../shape-3d.ts';

export class Cube extends Shape3d {
  readonly x: number;
  readonly y: number;
  readonly z: number;

  constructor(x: number, y: number, z: number) {
    super();
    this.x = x;
    this.y = y;
    this.z = z;
  }

  /**
   * @inheritDoc https://en.wikibooks.org/wiki/OpenSCAD_User_Manual/Primitive_Solids#cube
   */
  override toOpenscad(): string {
    // super.toOpenscad(...)
    return Object3d.prototype.toOpenscad.call(
      this,
      `cube(size = ${vector3ToOpenscad([this.x, this.y, this.z])}, center = true);`,
    );
  }
}

/*--*/

export function cube(x: number, y: number, z: number): Cube {
  return new Cube(x, y, z);
}
