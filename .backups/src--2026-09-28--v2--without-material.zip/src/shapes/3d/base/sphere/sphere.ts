import { numberToOpenscad } from '../../../../types/number/to/openscad/number-to-openscad.ts';
import { Object3d } from '../../../../types/object-3d/object-3d.ts';
import { Shape3d } from '../../shape-3d.ts';

export class Sphere extends Shape3d {
  readonly radius: number;
  readonly subDivisions: number;

  constructor(radius: number, subDivisions: number = 16) {
    super();
    this.radius = radius;
    this.subDivisions = subDivisions;
  }

  /**
   * @inheritDoc https://en.wikibooks.org/wiki/OpenSCAD_User_Manual/Primitive_Solids#sphere
   */
  override toOpenscad(): string {
    // super.toOpenscad(...)
    return Object3d.prototype.toOpenscad.call(
      this,
      `sphere(r = ${numberToOpenscad(this.radius)}, $fn = ${numberToOpenscad(this.subDivisions)});`,
    );
  }
}

/*--*/

export function sphere(radius: number, subDivisions?: number): Sphere {
  return new Sphere(radius, subDivisions);
}
