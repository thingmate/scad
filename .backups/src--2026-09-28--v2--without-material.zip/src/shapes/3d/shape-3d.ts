import { Object3d } from '../../types/object-3d/object-3d.ts';

export abstract class Shape3d extends Object3d {
  abstract override toOpenscad(): string;
}
