import { rgba } from '../create/rgba.ts';

export const COLOR_CONCRETE = rgba('rgb(98 98 98)');
